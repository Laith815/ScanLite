ضع هنا الملفين التاليين (مطلوبان لـ OCR):
  ara.traineddata
  eng.traineddata
حمّلهما من: https://github.com/tesseract-ocr/tessdata_fast
(نسخة fast أخف وأسرع. إن أردت دقة أعلى للعربية استخدم tessdata_best)
