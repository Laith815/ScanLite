package com.scanlite.app

import android.content.Context
import android.graphics.*
import android.net.Uri
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

data class Doc(val id: String, val title: String, val pages: List<File>)

class DocRepo(private val ctx: Context) {
    private val root get() = File(ctx.filesDir, "docs").apply { mkdirs() }

    fun list(): List<Doc> =
        root.listFiles()?.filter { it.isDirectory }?.sortedByDescending { it.name }
            ?.mapNotNull { load(it.name) } ?: emptyList()

    fun load(id: String): Doc? {
        val dir = File(root, id)
        if (!dir.exists()) return null
        val pages = dir.listFiles { f -> f.extension == "jpg" }?.sortedBy { it.name } ?: emptyList()
        val title = File(dir, "title.txt").takeIf { it.exists() }?.readText() ?: id
        return Doc(id, title, pages)
    }

    fun create(uris: List<Uri>): String {
        val id = System.currentTimeMillis().toString()
        val dir = File(root, id).apply { mkdirs() }
        uris.forEachIndexed { i, u ->
            ctx.contentResolver.openInputStream(u)?.use { input ->
                File(dir, "p%03d.jpg".format(i + 1)).outputStream().use { input.copyTo(it) }
            }
        }
        val t = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        File(dir, "title.txt").writeText("مستند $t")
        return id
    }

    fun delete(id: String) { File(root, id).deleteRecursively() }

    fun getFilter(id: String): ScanFilter {
        val f = File(File(root, id), "filter.txt")
        return if (f.exists()) runCatching { ScanFilter.valueOf(f.readText()) }.getOrDefault(ScanFilter.ENHANCED)
        else ScanFilter.ENHANCED
    }

    fun setFilter(id: String, filter: ScanFilter) {
        File(File(root, id), "filter.txt").writeText(filter.name)
    }
}

private fun contrast(c: Float, t: Float) = floatArrayOf(
    c, 0f, 0f, 0f, t,
    0f, c, 0f, 0f, t,
    0f, 0f, c, 0f, t,
    0f, 0f, 0f, 1f, 0f
)

private fun grayContrast(c: Float, t: Float) = floatArrayOf(
    .299f * c, .587f * c, .114f * c, 0f, t,
    .299f * c, .587f * c, .114f * c, 0f, t,
    .299f * c, .587f * c, .114f * c, 0f, t,
    0f, 0f, 0f, 1f, 0f
)

enum class ScanFilter(val label: String, val matrix: FloatArray?) {
    ORIGINAL("أصلي", null),
    ENHANCED("محسّن", contrast(1.35f, -35f)),
    BW("أبيض وأسود", grayContrast(1.8f, -90f))
}

fun decode(file: File, maxDim: Int): Bitmap {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, o)
    var s = 1
    while (maxOf(o.outWidth, o.outHeight) / s > maxDim) s *= 2
    return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = s })
}

fun applyFilter(src: Bitmap, f: ScanFilter): Bitmap {
    val m = f.matrix ?: return src
    val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
    val p = Paint().apply { colorFilter = ColorMatrixColorFilter(ColorMatrix(m)) }
    Canvas(out).drawBitmap(src, 0f, 0f, p)
    return out
}
