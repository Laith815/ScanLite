package com.scanlite.app

import android.content.*
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class ExportResult(val files: List<File>, val mime: String)

object Exporter {
    private fun outDir(ctx: Context) = File(ctx.cacheDir, "exports").apply { mkdirs() }
    private fun safeName(s: String) = s.replace(Regex("[^\\w\\u0600-\\u06FF-]+"), "_").trim('_')

    fun export(ctx: Context, doc: Doc, filter: ScanFilter, kind: String): ExportResult {
        val base = safeName(doc.title)
        return when (kind) {
            "pdf" -> {
                val f = File(outDir(ctx), "$base.pdf")
                makePdf(doc.pages, filter, f)
                saveToDownloads(ctx, f, "application/pdf")
                ExportResult(listOf(f), "application/pdf")
            }
            else -> {
                val files = doc.pages.mapIndexed { i, p ->
                    val f = File(outDir(ctx), "${base}_${i + 1}.jpg")
                    val raw = decode(p, 3000)
                    val bmp = applyFilter(raw, filter)
                    f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                    saveToDownloads(ctx, f, "image/jpeg")
                    f
                }
                ExportResult(files, "image/jpeg")
            }
        }
    }

    fun docx(ctx: Context, doc: Doc, text: String): ExportResult {
        val f = File(outDir(ctx), safeName(doc.title) + ".docx")
        makeDocx(text, f)
        val mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        saveToDownloads(ctx, f, mime)
        return ExportResult(listOf(f), mime)
    }

    private fun makePdf(pages: List<File>, filter: ScanFilter, out: File) {
        val pdf = PdfDocument()
        pages.forEachIndexed { i, f ->
            val bmp = applyFilter(decode(f, 1800), filter)
            val w = 595
            val h = (w * bmp.height.toFloat() / bmp.width).toInt()
            val page = pdf.startPage(PdfDocument.PageInfo.Builder(w, h, i + 1).create())
            page.canvas.drawBitmap(bmp, null, RectF(0f, 0f, w.toFloat(), h.toFloat()), Paint(Paint.FILTER_BITMAP_FLAG))
            pdf.finishPage(page)
            bmp.recycle()
        }
        out.outputStream().use { pdf.writeTo(it) }
        pdf.close()
    }

    private fun makeDocx(text: String, out: File) {
        fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        fun isAr(s: String) = s.any { it in '\u0600'..'\u06FF' }
        val paras = text.split(Regex("\\n\\s*\\n"))
            .map { it.lines().joinToString(" ") { l -> l.trim() }.trim() }
            .filter { it.isNotEmpty() }
        val body = paras.joinToString("") { p ->
            if (isAr(p))
                "<w:p><w:pPr><w:bidi/></w:pPr><w:r><w:rPr><w:rFonts w:cs=\"Arial\"/><w:rtl/></w:rPr><w:t xml:space=\"preserve\">${esc(p)}</w:t></w:r></w:p>"
            else
                "<w:p><w:r><w:t xml:space=\"preserve\">${esc(p)}</w:t></w:r></w:p>"
        }
        val head = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
        val contentTypes = head + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>"
        val rels = head + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>"
        val document = head + "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>$body</w:body></w:document>"
        ZipOutputStream(out.outputStream()).use { z ->
            fun put(name: String, c: String) { z.putNextEntry(ZipEntry(name)); z.write(c.toByteArray(Charsets.UTF_8)); z.closeEntry() }
            put("[Content_Types].xml", contentTypes)
            put("_rels/.rels", rels)
            put("word/document.xml", document)
        }
    }

    private fun saveToDownloads(ctx: Context, file: File, mime: String) {
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, file.name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ScanLite")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return
        ctx.contentResolver.openOutputStream(uri)?.use { o -> file.inputStream().use { it.copyTo(o) } }
    }

    fun share(ctx: Context, r: ExportResult) {
        val uris = ArrayList(r.files.map { FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", it) })
        val i = if (uris.size == 1) Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        else Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        i.type = r.mime
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "مشاركة"))
    }
}

object Ocr {
    private fun ensureData(ctx: Context): String {
        val dir = File(ctx.filesDir, "tessdata").apply { mkdirs() }
        for (lang in listOf("ara", "eng")) {
            val f = File(dir, "$lang.traineddata")
            if (!f.exists()) {
                try {
                    ctx.assets.open("tessdata/$lang.traineddata").use { i -> f.outputStream().use { i.copyTo(it) } }
                } catch (e: Exception) {
                    throw IllegalStateException("ملف $lang.traineddata غير موجود في assets/tessdata")
                }
            }
        }
        return ctx.filesDir.absolutePath
    }

    fun run(ctx: Context, pages: List<File>): String {
        val api = TessBaseAPI()
        try {
            if (!api.init(ensureData(ctx), "ara+eng")) throw IllegalStateException("فشل تحميل نماذج OCR")
            return pages.joinToString("\n\n") { f ->
                val raw = decode(f, 2400)
                val b = applyFilter(raw, ScanFilter.ENHANCED)
                api.setImage(b)
                val t = api.utf8Text ?: ""
                b.recycle()
                t.trim()
            }
        } finally {
            api.recycle()
        }
    }
}
