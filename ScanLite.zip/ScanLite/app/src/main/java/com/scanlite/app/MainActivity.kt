package com.scanlite.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val repo = remember { DocRepo(ctx) }
    var openId by rememberSaveable { mutableStateOf<String?>(null) }
    var refresh by remember { mutableIntStateOf(0) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val r = GmsDocumentScanningResult.fromActivityResultIntent(res.data)
            val uris = r?.pages?.map { it.imageUri } ?: emptyList()
            if (uris.isNotEmpty()) {
                openId = repo.create(uris)
                refresh++
            }
        }
    }

    fun startScan() {
        val opts = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setPageLimit(30)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        GmsDocumentScanning.getClient(opts).getStartScanIntent(ctx as Activity)
            .addOnSuccessListener { launcher.launch(IntentSenderRequest.Builder(it).build()) }
            .addOnFailureListener { Toast.makeText(ctx, "تعذر فتح الماسح: ${it.message}", Toast.LENGTH_LONG).show() }
    }

    val id = openId
    if (id == null) {
        val docs = remember(refresh) { repo.list() }
        HomeScreen(docs, onOpen = { openId = it }, onScan = ::startScan)
    } else {
        BackHandler { openId = null }
        DocScreen(repo, id, onBack = { openId = null; refresh++ })
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(docs: List<Doc>, onOpen: (String) -> Unit, onScan: () -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("ScanLite") }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onScan,
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text("مسح مستند") }
            )
        }
    ) { pad ->
        if (docs.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) { Text("لا توجد مستندات بعد") }
        } else {
            LazyColumn(Modifier.padding(pad)) {
                items(docs, key = { it.id }) { d ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onOpen(d.id) }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Thumb(d.pages.firstOrNull())
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(d.title, style = MaterialTheme.typography.titleMedium)
                            Text("${d.pages.size} صفحة", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Thumb(f: File?) {
    val bmp by produceState<Bitmap?>(null, f) {
        value = f?.let { withContext(Dispatchers.IO) { decode(it, 200) } }
    }
    Box(Modifier.size(56.dp, 72.dp).background(Color.LightGray)) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

@Composable
fun PageImage(f: File, filter: ScanFilter) {
    val bmp by produceState<Bitmap?>(null, f) { value = withContext(Dispatchers.IO) { decode(f, 1400) } }
    val cf = filter.matrix?.let { ColorFilter.colorMatrix(androidx.compose.ui.graphics.ColorMatrix(it)) }
    val b = bmp
    if (b == null) Box(Modifier.fillMaxWidth().height(300.dp).background(Color.LightGray))
    else Image(b.asImageBitmap(), null, Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth, colorFilter = cf)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocScreen(repo: DocRepo, id: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val d = remember { repo.load(id) }
    if (d == null) { LaunchedEffect(Unit) { onBack() }; return }

    var filter by remember { mutableStateOf(repo.getFilter(id)) }
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<ExportResult?>(null) }
    var ocrText by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    fun fail(e: Exception) { Toast.makeText(ctx, "خطأ: ${e.message}", Toast.LENGTH_LONG).show() }

    fun export(kind: String) {
        busy = true
        scope.launch {
            try { result = withContext(Dispatchers.IO) { Exporter.export(ctx, d, filter, kind) } }
            catch (e: Exception) { fail(e) }
            busy = false
        }
    }

    fun extractText() {
        busy = true
        scope.launch {
            try { ocrText = withContext(Dispatchers.IO) { Ocr.run(ctx, d.pages) } }
            catch (e: Exception) { fail(e) }
            busy = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(d.title) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
                actions = { IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.Delete, null) } }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Column(Modifier.padding(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ScanFilter.values().forEach { f ->
                            FilterChip(
                                selected = filter == f,
                                onClick = { filter = f; repo.setFilter(id, f) },
                                label = { Text(f.label) }
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { export("pdf") }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("PDF") }
                        Button(onClick = { export("img") }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("صور") }
                        Button(onClick = { extractText() }, enabled = !busy, modifier = Modifier.weight(1.4f)) { Text("نص / Word") }
                    }
                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
                }
            }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(d.pages, key = { it.name }) { PageImage(it, filter) }
        }
    }

    result?.let { r ->
        AlertDialog(
            onDismissRequest = { result = null },
            title = { Text("تم الحفظ في التنزيلات/ScanLite") },
            confirmButton = { Button(onClick = { Exporter.share(ctx, r); result = null }) { Text("مشاركة") } },
            dismissButton = { TextButton(onClick = { result = null }) { Text("إغلاق") } }
        )
    }

    ocrText?.let { t ->
        AlertDialog(
            onDismissRequest = { ocrText = null },
            title = { Text("النص المستخرج") },
            text = {
                OutlinedTextField(
                    value = t,
                    onValueChange = { ocrText = it },
                    modifier = Modifier.fillMaxWidth().height(320.dp)
                )
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = {
                        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("ocr", t))
                        Toast.makeText(ctx, "تم النسخ", Toast.LENGTH_SHORT).show()
                    }) { Text("نسخ") }
                    Button(onClick = {
                        busy = true
                        scope.launch {
                            try { result = withContext(Dispatchers.IO) { Exporter.docx(ctx, d, t) }; ocrText = null }
                            catch (e: Exception) { fail(e) }
                            busy = false
                        }
                    }) { Text("حفظ Word") }
                }
            },
            dismissButton = { TextButton(onClick = { ocrText = null }) { Text("إغلاق") } }
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("حذف المستند؟") },
            confirmButton = { Button(onClick = { repo.delete(id); confirmDelete = false; onBack() }) { Text("حذف") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("إلغاء") } }
        )
    }
}
